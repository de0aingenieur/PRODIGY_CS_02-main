Task # 02
Pixel Manipulation for Image Encryption
Develop a simple image encryption tool using pixel manipulation. 
You can perform operations like swapping pixel values or 
applying a basic mathematical operation to each pixel. 
Allow users to encrypt and decrypt images.

Here is a simple program of an image encryption tool using pixel manipulation in Python.
In this program, basic mathematical operation (XOR) are used to encrypt and decrypt the image.
This program uses the Pillow library for image processing. 
If you haven't installed it yet, you can do so by running "pip install Pillow" on VS Code terminal.
